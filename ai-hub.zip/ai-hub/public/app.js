const PROVIDERS = [
  { id: 'chatgpt', name: 'ChatGPT', icon: '✳', logo: 'logo-openai', tagline: 'Универсальный помощник' },
  { id: 'claude', name: 'Claude', icon: '✳', logo: 'logo-claude', tagline: 'Тексты и глубокий анализ' },
  { id: 'gemini', name: 'Gemini', icon: '✦', logo: 'logo-gemini', tagline: 'Идеи и мультимодальность' },
  { id: 'grok', name: 'Grok', icon: '𝕏', logo: 'logo-grok', tagline: 'Прямой взгляд на задачи' },
  { id: 'kimi', name: 'Kimi', icon: '月', logo: 'logo-kimi', tagline: 'Большие задачи и документы' }
];
const STORAGE_KEY = 'aihub-conversations-v1';
const PREF_KEY = 'aihub-preferences-v1';
const ACCESS_KEY = 'aihub-session-access-code';
const $ = (selector) => document.querySelector(selector);
const els = {
  sidebar: $('#sidebar'), providerList: $('#providerList'), modelCards: $('#modelCards'), historyList: $('#historyList'),
  historySearch: $('#historySearch'), welcome: $('#welcomeScreen'), chat: $('#chatView'), messages: $('#messages'),
  title: $('#chatTitle'), providerTitle: $('#activeProviderTitle'), modelPill: $('#selectedModelPill'),
  modeIndicator: $('#modeIndicator'), modeText: $('#modeText'), input: $('#promptInput'), send: $('#sendButton'),
  charCount: $('#charCount'), overlay: $('#settingsOverlay'), connectionList: $('#connectionList'), toast: $('#toast')
};
let conversations = loadConversations();
let activeConversationId = null;
let activeProvider = 'chatgpt';
let providerStatus = {};
let busy = false;
let activeControllers = [];
let busyConversation = null;
let toastTimer = null;
let currentTheme = 'dark';

function loadConversations() {
  try {
    const value = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    return Array.isArray(value) ? value.filter((c) => c && typeof c.id === 'string' && Array.isArray(c.messages)) : [];
  } catch { return []; }
}
function loadPreferences() {
  try { return JSON.parse(localStorage.getItem(PREF_KEY) || '{}'); } catch { return {}; }
}
function saveAll() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(conversations.slice(-80)));
    localStorage.setItem(PREF_KEY, JSON.stringify({ provider: activeProvider, theme: currentTheme }));
  } catch { showToast('Не удалось сохранить историю. Возможно, переполнено хранилище браузера.'); }
}
function makeId() { return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`; }
function currentConversation() { return conversations.find((item) => item.id === activeConversationId) || null; }
function providerById(id) { return PROVIDERS.find((provider) => provider.id === id) || PROVIDERS[0]; }
function nowLabel() { return new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }); }
function safeText(value) { return String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char])); }
function showToast(message) {
  els.toast.textContent = message;
  els.toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => els.toast.classList.remove('show'), 2600);
}
function setProvider(id) {
  if (!providerById(id)) return;
  activeProvider = id;
  const item = providerById(id);
  els.providerTitle.textContent = item.name;
  els.modelPill.innerHTML = `<span class="tiny-logo ${item.logo}">${item.icon}</span><span>${item.name}</span><span class="chevron">⌄</span>`;
  document.querySelectorAll('[data-provider]').forEach((button) => {
    const selected = button.dataset.provider === id;
    button.classList.toggle('active', selected);
    button.classList.toggle('selected', selected);
  });
  document.querySelectorAll('.provider-option').forEach((button) => button.classList.toggle('configured', Boolean(providerStatus[button.dataset.provider]?.configured)));
  updateModeIndicator();
  saveAll();
}
function updateModeIndicator() {
  const configured = Boolean(providerStatus[activeProvider]?.configured);
  els.modeIndicator.classList.toggle('live', configured);
  els.modeText.textContent = configured ? 'API ПОДКЛЮЧЁН' : 'ДЕМО-РЕЖИМ';
}
function newChat() {
  activeConversationId = null;
  els.input.value = '';
  updateComposerCount();
  renderWorkspace();
  renderHistory();
  closeSidebarOnMobile();
  els.input.focus();
}
function ensureConversation() {
  let conversation = currentConversation();
  if (!conversation) {
    conversation = { id: makeId(), title: 'Новый диалог', createdAt: Date.now(), updatedAt: Date.now(), messages: [] };
    conversations.unshift(conversation);
    activeConversationId = conversation.id;
  }
  return conversation;
}
function addUserMessage(content) {
  const conversation = ensureConversation();
  if (conversation.messages.filter((m) => m.role === 'user').length === 0) {
    conversation.title = content.replace(/\s+/g, ' ').trim().slice(0, 42) || 'Новый диалог';
  }
  conversation.messages.push({ id: makeId(), role: 'user', content, time: nowLabel() });
  conversation.updatedAt = Date.now();
  saveAll();
  return conversation;
}
function addAssistantMessage(conversation, content, provider, extra = {}) {
  const message = { id: makeId(), role: 'assistant', content, provider, time: nowLabel(), ...extra };
  conversation.messages.push(message);
  conversation.updatedAt = Date.now();
  saveAll();
  return message;
}
function renderWorkspace() {
  const conversation = currentConversation();
  const hasMessages = Boolean(conversation?.messages?.length);
  els.welcome.classList.toggle('hidden', hasMessages);
  els.chat.classList.toggle('hidden', !hasMessages);
  if (!hasMessages) return;
  els.title.textContent = conversation.title || 'Новый диалог';
  renderMessages();
}
function inlineMarkdown(text) {
  let html = safeText(text);
  html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/(^|[^*])\*([^*]+)\*/g, '$1<em>$2</em>');
  html = html.replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>');
  return html;
}
function markdownToHtml(text) {
  const normalized = String(text || '').replace(/\r/g, '');
  const chunks = normalized.split(/```/);
  let output = '';
  chunks.forEach((chunk, index) => {
    if (index % 2 === 1) {
      const lines = chunk.split('\n');
      if (lines.length && /^[a-zA-Z0-9_+#.-]{1,20}$/.test(lines[0].trim())) lines.shift();
      output += `<pre><code>${safeText(lines.join('\n'))}</code></pre>`;
      return;
    }
    let lines = chunk.split('\n');
    let paragraph = [];
    const flush = () => {
      if (paragraph.length) output += `<p>${paragraph.map(inlineMarkdown).join('<br>')}</p>`;
      paragraph = [];
    };
    let listType = null;
    let listItems = [];
    const flushList = () => {
      if (listItems.length) output += `<${listType}><li>${listItems.map(inlineMarkdown).join('</li><li>')}</li></${listType}>`;
      listItems = []; listType = null;
    };
    for (const line of lines) {
      const trimmed = line.trim();
      const bullet = trimmed.match(/^[-*•]\s+(.+)/);
      const numbered = trimmed.match(/^\d+[.)]\s+(.+)/);
      if (!trimmed) { flush(); flushList(); continue; }
      if (bullet || numbered) {
        flush();
        const nextType = bullet ? 'ul' : 'ol';
        if (listType && listType !== nextType) flushList();
        listType = nextType;
        listItems.push((bullet || numbered)[1]);
        continue;
      }
      flushList();
      const heading = trimmed.match(/^#{1,3}\s+(.+)/);
      if (heading) { flush(); output += `<p><strong>${inlineMarkdown(heading[1])}</strong></p>`; }
      else paragraph.push(line);
    }
    flush(); flushList();
  });
  return output || '<p></p>';
}
function renderMessages() {
  const conversation = currentConversation();
  if (!conversation) return;
  els.messages.innerHTML = conversation.messages.map((message) => {
    if (message.typing) {
      const waitingProvider = providerById(message.provider || activeProvider);
      return `<article class="message assistant" data-message-id="${safeText(message.id)}"><div class="message-avatar assistant-avatar ${waitingProvider.logo}">${waitingProvider.icon}</div><div class="message-content"><div class="message-meta"><b>${waitingProvider.name}</b><span>печатает</span></div><div class="typing-indicator"><i></i><i></i><i></i></div></div></article>`;
    }
    const isUser = message.role === 'user';
    const provider = providerById(message.provider || activeProvider);
    const name = isUser ? 'Вы' : provider.name;
    const avatar = isUser ? 'Я' : provider.icon;
    const avatarClass = isUser ? 'user-avatar' : `assistant-avatar ${provider.logo}`;
    const demoTag = message.demo ? '<span class="demo-tag">ДЕМО</span>' : '';
    const body = message.error ? `<div class="error-bubble">${safeText(message.content)} <button data-action="retry">Повторить</button></div>` : `<div class="message-bubble">${isUser ? safeText(message.content).replace(/\n/g, '<br>') : markdownToHtml(message.content)}</div>`;
    const actions = isUser || message.error ? '' : `<div class="message-actions"><button data-action="copy" data-id="${safeText(message.id)}">Копировать</button>${conversation.messages[conversation.messages.length - 1]?.id === message.id ? '<button data-action="regenerate">Повторить ответ</button>' : ''}</div>`;
    const time = safeText(message.time || '');
    return `<article class="message ${isUser ? 'user' : 'assistant'}" data-message-id="${safeText(message.id)}"><div class="message-avatar ${avatarClass}">${avatar}</div><div class="message-content"><div class="message-meta"><b>${name}</b><span>${time}</span>${demoTag}</div>${body}${actions}</div></article>`;
  }).join('');
  els.messages.scrollTop = els.messages.scrollHeight;
}
function renderHistory() {
  const query = (els.historySearch.value || '').toLocaleLowerCase('ru');
  const filtered = conversations.filter((conversation) => (conversation.title || '').toLocaleLowerCase('ru').includes(query));
  if (!filtered.length) {
    els.historyList.innerHTML = `<div class="history-empty">${query ? 'Ничего не найдено.' : 'Твои диалоги будут появляться здесь.'}</div>`;
    return;
  }
  els.historyList.innerHTML = filtered.map((conversation) => `<div class="history-item ${conversation.id === activeConversationId ? 'active' : ''}" data-id="${safeText(conversation.id)}"><span class="history-icon">◷</span><span>${safeText(conversation.title || 'Новый диалог')}</span><button class="history-delete" data-delete="${safeText(conversation.id)}" aria-label="Удалить диалог">×</button></div>`).join('');
}
function updateComposerCount() {
  const count = els.input.value.length;
  els.charCount.textContent = `${count.toLocaleString('ru-RU')} / 12 000`;
  els.send.disabled = (!busy && !els.input.value.trim()) || count > 12000;
  els.input.style.height = 'auto';
  els.input.style.height = `${Math.min(165, Math.max(33, els.input.scrollHeight))}px`;
}
function setBusy(value) {
  busy = value;
  els.send.classList.toggle('stop', value);
  els.send.innerHTML = value ? '<span>■</span>' : '<span>↑</span>';
  els.send.setAttribute('aria-label', value ? 'Остановить запрос' : 'Отправить сообщение');
  els.input.disabled = value;
  if (value) els.send.disabled = false;
  else updateComposerCount();
}
function addTypingMessage(conversation, providerId) {
  const provider = providerById(providerId);
  const typing = { id: `typing-${providerId}`, provider: providerId, role: 'assistant', typing: true };
  conversation.messages.push(typing);
  renderMessages();
}
function removeTyping(conversation, providerId) {
  conversation.messages = conversation.messages.filter((message) => message.id !== `typing-${providerId}`);
}
function replaceTyping(conversation, providerId, content, extra = {}) {
  removeTyping(conversation, providerId);
  addAssistantMessage(conversation, content, providerId, extra);
  renderWorkspace();
}
// Extend rendering for active 

async function callProvider(providerId, messages, controller) {
  const response = await fetch('/api/chat', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-App-Access': sessionStorage.getItem(ACCESS_KEY) || ''
    },
    body: JSON.stringify({ provider: providerId, messages }),
    signal: controller.signal
  });
  let data = {};
  try { data = await response.json(); } catch { /* handled below */ }
  if (!response.ok) throw new Error(data.error || `Ошибка сервера: ${response.status}`);
  if (typeof data.content !== 'string') throw new Error('Сервис вернул ответ в неизвестном формате.');
  return data;
}
function apiMessages(conversation) {
  return conversation.messages
    .filter((message) => ['user', 'assistant'].includes(message.role) && !message.error && typeof message.content === 'string')
    .slice(-30)
    .map((message) => ({ role: message.role, content: message.content }));
}
async function requestExistingUser(conversation, providerId) {
  if (busy) return;
  const lastUser = [...conversation.messages].reverse().find((message) => message.role === 'user');
  if (!lastUser) { showToast('Сначала напиши сообщение.'); return; }
  const controller = new AbortController();
  activeControllers = [controller];
  busyConversation = conversation;
  const messages = apiMessages(conversation);
  addTypingMessage(conversation, providerId);
  if (activeConversationId === conversation.id) renderWorkspace();
  setBusy(true);
  try {
    const result = await callProvider(providerId, messages, controller);
    removeTyping(conversation, providerId);
    addAssistantMessage(conversation, result.content, providerId, { demo: result.demo });
    if (activeConversationId === conversation.id) renderWorkspace();
    renderHistory();
  } catch (error) {
    removeTyping(conversation, providerId);
    if (!controller.signal.aborted) {
      addAssistantMessage(conversation, error.message || 'Не удалось получить ответ.', providerId, { error: true });
      if (activeConversationId === conversation.id) renderWorkspace();
      showToast('Не удалось получить ответ. Проверь подключение и настройки.');
    }
  } finally {
    activeControllers = [];
    busyConversation = null;
    setBusy(false);
  }
}
async function sendMessage() {
  if (busy) { stopRequests(); return; }
  const content = els.input.value.trim();
  if (!content) return;
  if (content.length > 12000) { showToast('Сообщение слишком длинное.'); return; }
  const conversation = addUserMessage(content);
  const providerId = activeProvider;
  els.input.value = '';
  updateComposerCount();
  renderWorkspace();
  renderHistory();
  await requestExistingUser(conversation, providerId);
}
async function compareAll() {
  if (busy) { stopRequests(); return; }
  const content = els.input.value.trim();
  if (!content) { showToast('Сначала напиши сообщение для сравнения.'); els.input.focus(); return; }
  const confirmed = window.confirm('Отправить один запрос всем пяти ИИ? Если API-ключи подключены, каждый сервис может списать плату за свой запрос.');
  if (!confirmed) return;
  if (content.length > 12000) { showToast('Сообщение слишком длинное.'); return; }
  const conversation = addUserMessage(content);
  els.input.value = '';
  updateComposerCount();
  const providers = PROVIDERS.map((provider) => provider.id);
  let received = 0;
  const messages = apiMessages(conversation);
  const controllers = providers.map(() => new AbortController());
  activeControllers = controllers;
  busyConversation = conversation;
  providers.forEach((id) => addTypingMessage(conversation, id));
  renderWorkspace();
  renderHistory();
  setBusy(true);
  await Promise.all(providers.map(async (providerId, index) => {
    try {
      const result = await callProvider(providerId, messages, controllers[index]);
      received += 1;
      replaceTyping(conversation, providerId, result.content, { demo: result.demo });
    } catch (error) {
      removeTyping(conversation, providerId);
      if (!controllers[index].signal.aborted) addAssistantMessage(conversation, error.message || 'Не удалось получить ответ.', providerId, { error: true });
      if (activeConversationId === conversation.id) renderWorkspace();
    }
    renderHistory();
  }));
  activeControllers = [];
  busyConversation = null;
  setBusy(false);
  if (activeConversationId === conversation.id) renderWorkspace();
  showToast(`Сравнение завершено: получено ответов — ${received} из 5.`);
}
function stopRequests() {
  if (!busy) return;
  activeControllers.forEach((controller) => controller.abort());
  activeControllers = [];
  const conversation = busyConversation || currentConversation();
  if (conversation) {
    conversation.messages = conversation.messages.filter((message) => !message.typing);
    saveAll();
    if (activeConversationId === conversation.id) renderWorkspace();
  }
  // The in-flight request's finally handler releases the busy state after abort.
  showToast('Запрос остановлен.');
}
function regenerateLast() {
  const conversation = currentConversation();
  if (!conversation || busy) return;
  const lastAssistantIndex = [...conversation.messages].map((message) => message.role).lastIndexOf('assistant');
  let providerId = activeProvider;
  if (lastAssistantIndex >= 0) {
    providerId = conversation.messages[lastAssistantIndex].provider || activeProvider;
    conversation.messages.splice(lastAssistantIndex, 1);
  }
  saveAll();
  renderWorkspace();
  requestExistingUser(conversation, providerId);
}
function deleteConversation(id) {
  const conversation = conversations.find((item) => item.id === id);
  if (!conversation) return;
  if (!window.confirm(`Удалить диалог «${conversation.title}»?`)) return;
  conversations = conversations.filter((item) => item.id !== id);
  if (activeConversationId === id) activeConversationId = null;
  saveAll();
  renderWorkspace();
  renderHistory();
  showToast('Диалог удалён.');
}
function clearHistory() {
  if (!conversations.length) { showToast('История уже пуста.'); return; }
  if (!window.confirm('Удалить все сохранённые диалоги на этом устройстве?')) return;
  conversations = [];
  activeConversationId = null;
  saveAll();
  renderWorkspace();
  renderHistory();
  showToast('История очищена.');
}
function exportConversation() {
  const conversation = currentConversation();
  if (!conversation?.messages?.length) { showToast('В этом диалоге пока нет сообщений.'); return; }
  const lines = [`${conversation.title || 'Диалог'}`, `Экспортировано: ${new Date().toLocaleString('ru-RU')}`, ''];
  conversation.messages.filter((message) => !message.typing).forEach((message) => {
    const name = message.role === 'user' ? 'Вы' : providerById(message.provider || activeProvider).name;
    lines.push(`${name}:`, message.content || '', '');
  });
  const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `${(conversation.title || 'ai-hub-dialog').replace(/[^\p{L}\p{N}-]+/gu, '-').slice(0, 45)}.txt`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
  showToast('Диалог подготовлен к скачиванию.');
}
async function copyMessage(id) {
  const conversation = currentConversation();
  const message = conversation?.messages.find((item) => item.id === id);
  if (!message) return;
  try {
    await navigator.clipboard.writeText(message.content);
    showToast('Ответ скопирован.');
  } catch {
    const field = document.createElement('textarea');
    field.value = message.content;
    document.body.appendChild(field); field.select();
    const ok = document.execCommand('copy'); field.remove();
    showToast(ok ? 'Ответ скопирован.' : 'Не удалось скопировать текст.');
  }
}
async function refreshStatus() {
  try {
    const response = await fetch('/api/status', { cache: 'no-store' });
    if (!response.ok) throw new Error('status');
    const data = await response.json();
    providerStatus = Object.fromEntries((data.providers || []).map((item) => [item.id, item]));
  } catch {
    providerStatus = {};
  }
  document.querySelectorAll('.provider-option').forEach((button) => button.classList.toggle('configured', Boolean(providerStatus[button.dataset.provider]?.configured)));
  updateModeIndicator();
  renderConnections();
}
function renderConnections() {
  els.connectionList.innerHTML = PROVIDERS.map((provider) => {
    const status = providerStatus[provider.id];
    const connected = Boolean(status?.configured);
    const model = status?.model || 'модель по умолчанию';
    return `<div class="connection-item"><span class="provider-logo ${provider.logo}">${provider.icon}</span><div><b>${provider.name}</b><small>${safeText(model)}</small></div><span class="connection-state ${connected ? 'ok' : ''}">${connected ? 'Подключён' : 'Нет ключа · демо'}</span></div>`;
  }).join('');
}
function openSettings() {
  renderConnections();
  $('#accessCodeInput').value = sessionStorage.getItem(ACCESS_KEY) || '';
  els.overlay.classList.remove('hidden');
}
function closeSettings() { els.overlay.classList.add('hidden'); }
function openSidebar() { els.sidebar.classList.add('open'); }
function closeSidebarOnMobile() { if (window.matchMedia('(max-width: 760px)').matches) els.sidebar.classList.remove('open'); }
function toggleTheme() {
  currentTheme = currentTheme === 'dark' ? 'light' : 'dark';
  document.body.classList.toggle('light', currentTheme === 'light');
  saveAll();
}

// Event wiring: every visible control has a working action.
els.providerList.addEventListener('click', (event) => {
  const button = event.target.closest('[data-provider]');
  if (!button) return;
  setProvider(button.dataset.provider);
  closeSidebarOnMobile();
});
els.modelCards.addEventListener('click', (event) => {
  const button = event.target.closest('[data-provider]');
  if (button) setProvider(button.dataset.provider);
});
els.historyList.addEventListener('click', (event) => {
  const deleteButton = event.target.closest('[data-delete]');
  if (deleteButton) { event.stopPropagation(); deleteConversation(deleteButton.dataset.delete); return; }
  const item = event.target.closest('[data-id]');
  if (!item) return;
  activeConversationId = item.dataset.id;
  renderWorkspace(); renderHistory(); closeSidebarOnMobile();
});
els.messages.addEventListener('click', (event) => {
  const button = event.target.closest('[data-action]');
  if (!button) return;
  if (button.dataset.action === 'copy') copyMessage(button.dataset.id);
  else if (button.dataset.action === 'regenerate') regenerateLast();
  else if (button.dataset.action === 'retry') {
    const conversation = currentConversation();
    const error = [...(conversation?.messages || [])].reverse().find((message) => message.error);
    if (error) {
      const providerId = error.provider || activeProvider;
      conversation.messages = conversation.messages.filter((message) => message.id !== error.id);
      saveAll(); renderWorkspace(); requestExistingUser(conversation, providerId);
    }
  }
});
$('#newChat').addEventListener('click', newChat);
$('#clearHistory').addEventListener('click', clearHistory);
$('#sendButton').addEventListener('click', sendMessage);
$('#compareHint').addEventListener('click', compareAll);
els.input.addEventListener('input', updateComposerCount);
els.input.addEventListener('keydown', (event) => {
  if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
    event.preventDefault();
    if (!busy) sendMessage();
  }
});
$('#historySearch').addEventListener('input', renderHistory);
$('#exportChat').addEventListener('click', exportConversation);
$('#themeToggle').addEventListener('click', toggleTheme);
$('#openSettings').addEventListener('click', openSettings);
$('#openSettingsTop').addEventListener('click', openSettings);
$('#closeSettings').addEventListener('click', closeSettings);
$('#doneSettings').addEventListener('click', closeSettings);
$('#saveAccessCode').addEventListener('click', () => {
  const value = $('#accessCodeInput').value.trim();
  if (value) sessionStorage.setItem(ACCESS_KEY, value);
  else sessionStorage.removeItem(ACCESS_KEY);
  showToast(value ? 'Код доступа сохранён для этой вкладки.' : 'Код доступа очищен.');
});
els.overlay.addEventListener('click', (event) => { if (event.target === els.overlay) closeSettings(); });
$('#openSidebar').addEventListener('click', openSidebar);
$('#closeSidebar').addEventListener('click', closeSidebarOnMobile);
$('#deleteCurrent').addEventListener('click', () => { const conversation = currentConversation(); if (conversation) deleteConversation(conversation.id); });
els.modelPill.addEventListener('click', () => {
  const index = PROVIDERS.findIndex((provider) => provider.id === activeProvider);
  const next = PROVIDERS[(index + 1) % PROVIDERS.length];
  setProvider(next.id);
  showToast(`Выбрана модель ${next.name}`);
});
$('#addContext').addEventListener('click', () => {
  const addition = 'Ответь структурированно: сначала краткий вывод, затем шаги и пример.';
  const current = els.input.value.trim();
  els.input.value = current ? `${current}\n\n${addition}` : addition;
  updateComposerCount(); els.input.focus();
});
document.querySelectorAll('.suggestion-chip').forEach((button) => button.addEventListener('click', () => {
  els.input.value = button.dataset.prompt || '';
  updateComposerCount(); els.input.focus();
}));
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') { closeSettings(); els.sidebar.classList.remove('open'); }
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); newChat(); }
});

// Restore saved preferences and previous chat.
const preferences = loadPreferences();
if (preferences.theme === 'light') { currentTheme = 'light'; document.body.classList.add('light'); }
if (PROVIDERS.some((provider) => provider.id === preferences.provider)) activeProvider = preferences.provider;
if (conversations.length) activeConversationId = conversations[0].id;
setProvider(activeProvider);
renderWorkspace();
renderHistory();
updateComposerCount();
refreshStatus();

if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
  window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
}
