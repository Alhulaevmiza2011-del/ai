import { handleChat } from '../lib/providers.js';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Метод не поддерживается.' });
    return;
  }
  const requiredCode = process.env.APP_ACCESS_CODE;
  const suppliedCode = req.headers?.['x-app-access'];
  if (requiredCode && suppliedCode !== requiredCode) {
    res.status(401).json({ error: 'Неверный код доступа. Открой настройки и введи код, установленный на сервере.' });
    return;
  }
  try {
    const result = await handleChat(req.body || {});
    res.status(200).json(result);
  } catch (error) {
    res.status(400).json({ error: error.message || 'Ошибка запроса.' });
  }
}
